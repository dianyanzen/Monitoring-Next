// FILE: src/app/tracking-pengajuan/page.tsx
"use client";

import dynamic from "next/dynamic";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  CheckCircle2,
  Clock3,
  FilePlus2,
  Loader2,
  RefreshCcw,
  Search,
  ShieldCheck,
  X,
} from "lucide-react";
import { useSession } from "@/contexts/session";
import DateRangePopup from "@/components/ui/DateRangePopup";
import NeonModal, { type ModalKind } from "@/components/ui/NeonModal";
import SelectDark from "@/components/ui/SelectDark";
import SettingPageHeader from "@/components/setting/SettingPageHeader";

const JQDataTable = dynamic(() => import("@/components/datatable/JQDataTable"), {
  ssr: false,
  loading: () => <div className="px-4 py-5 text-sm text-cyan-100/70">Menyiapkan tabel...</div>,
});

const STATUSES = ["BERKAS_MASUK", "SELESAI", "DIAMBIL", "BATAL"] as const;
type TrackingStatus = (typeof STATUSES)[number];
const STATUS_LABELS: Record<TrackingStatus, string> = {
  BERKAS_MASUK: "BERKAS MASUK",
  SELESAI: "SELESAI",
  DIAMBIL: "DIAMBIL",
  BATAL: "BATAL",
};

type LocationOption = { locationId: number; code: string; name: string; type: string };
type ProductOption = { productId: number; code: string; name: string };
type RelationOption = { locationId: number; productId: number };
type WilayahOption = { value: string; label: string };
type KtpelMeta = {
  defaults: { noProp: string; noKab: string; noKec: string; noKel: string };
  wilayah: { kecamatan: WilayahOption[]; kelurahan: WilayahOption[] };
};
type TrackingRow = {
  trackingId: number;
  registrationNo: string;
  locationId: number;
  locationCode: string;
  locationName: string;
  productId: number;
  productCode: string;
  productName: string;
  nik: string;
  name: string;
  kecamatan: string;
  kelurahan: string;
  alamat: string;
  rw: string;
  rt: string;
  phone: string;
  email: string;
  status: TrackingStatus;
  statusLabel?: string;
  createdBy: string;
  createdDate: string;
  createdTime: string;
};
type SearchRow = {
  trackingId: number;
  registrationNo: string;
  name: string;
  nik: string;
  productName: string;
  locationName: string;
  date: string;
  status: TrackingStatus;
  statusLabel?: string;
};

const emptyForm = {
  locationId: "",
  productId: "",
  nik: "",
  name: "",
  noKec: "0",
  noKel: "0",
  kecamatan: "",
  kelurahan: "",
  alamat: "",
  rw: "",
  rt: "",
  phone: "",
  email: "",
  notes: "",
};

const toLocalIso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const normalizeDigits = (value: string, max = 16) => value.replace(/\D/g, "").slice(0, max);
const qrUrl = (value: string) => {
  const targetUrl = `https://disdukcapil.bandung.go.id/api/web/cekresi?resi=${encodeURIComponent(value)}`;
  return `https://api.qrserver.com/v1/create-qr-code/?size=132x132&data=${encodeURIComponent(targetUrl)}`;
};

const actionIcons = {
  print: `<svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V4h12v5"/><rect x="6" y="13" width="12" height="7" rx="2"/><path d="M6 17H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-1"/><path d="M9 17h6"/></svg>`,
  edit: `<svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
  trash: `<svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v5"/><path d="M14 11v5"/></svg>`,
  status: `<svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 7v5l3 2"/></svg>`,
} as const;

function statusClass(status: string) {
  if (status === "BERKAS_MASUK") return "border-cyan-400/40 bg-cyan-500/15 text-cyan-100";
  if (status === "SELESAI") return "border-emerald-400/40 bg-emerald-500/15 text-emerald-100";
  if (status === "DIAMBIL") return "border-blue-400/40 bg-blue-500/15 text-blue-100";
  return "border-rose-400/40 bg-rose-500/15 text-rose-100";
}

function nextStatuses(status: TrackingStatus) {
  if (status === "BERKAS_MASUK") return ["SELESAI", "BATAL"] as TrackingStatus[];
  if (status === "SELESAI") return ["DIAMBIL"] as TrackingStatus[];
  return [] as TrackingStatus[];
}

function statusLabel(status: string) {
  return STATUS_LABELS[status as TrackingStatus] || status;
}

function convertWilayahCode(raw: string | null | undefined) {
  const val = (raw ?? "").trim();
  if (!val) return "0";
  const digits = val.replace(/[^\d]/g, "");
  if (!digits || digits === "0" || digits === "000") return "0";
  const normalized = Number(digits);
  return Number.isNaN(normalized) ? digits : String(normalized);
}

function mergeOptions(options: WilayahOption[], includeDefault: boolean, defaultLabel: string) {
  const merged: WilayahOption[] = [];
  const seen = new Set<string>();
  if (includeDefault) {
    merged.push({ value: "0", label: defaultLabel });
    seen.add("0");
  }
  for (const opt of options) {
    const value = (opt.value ?? "").trim() || "0";
    if (!seen.has(value)) {
      merged.push({ value, label: opt.label });
      seen.add(value);
    }
  }
  return merged;
}

function selectedWilayahLabel(options: WilayahOption[], value: string) {
  if (!value || value === "0") return "";
  return options.find((opt) => opt.value === value)?.label || "";
}

export default function TrackingPengajuanPage() {
  const { user } = useSession();
  const today = useMemo(() => toLocalIso(new Date()), []);
  const [locations, setLocations] = useState<LocationOption[]>([]);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [relations, setRelations] = useState<RelationOption[]>([]);
  const [ktpelMeta, setKtpelMeta] = useState<KtpelMeta | null>(null);
  const [kecamatanOptions, setKecamatanOptions] = useState<WilayahOption[]>([]);
  const [kelurahanCache, setKelurahanCache] = useState<Record<string, WilayahOption[]>>({});
  const [kelurahanLoadingKey, setKelurahanLoadingKey] = useState<string | null>(null);
  const [rows, setRows] = useState<TrackingRow[]>([]);
  const [summary, setSummary] = useState<Record<string, number>>({});
  const [form, setForm] = useState(emptyForm);
  const [nikLookupLoading, setNikLookupLoading] = useState(false);
  const lastNikLookupRef = useRef("");
  const [filters, setFilters] = useState({
    start: today,
    end: today,
    locationId: "",
    productId: "",
    status: "",
    petugas: "",
    nik: "",
    registrationNo: "",
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [searchRows, setSearchRows] = useState<SearchRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [searching, setSearching] = useState(false);
  const [editingRowId, setEditingRowId] = useState<number | null>(null);
  const [statusModal, setStatusModal] = useState<{ row: TrackingRow; next: TrackingStatus[] } | null>(null);
  const [statusValue, setStatusValue] = useState<TrackingStatus | "">("");
  const [statusDescription, setStatusDescription] = useState("");
  const [notice, setNotice] = useState<{ kind: ModalKind; title: string; message: string } | null>(null);
  const tableHostRef = useRef<HTMLElement | null>(null);

  const userLocationScope = useMemo(() => {
    const noKec = Number(user?.S_NO_KEC ?? 0);
    const noKab = Number(user?.S_NO_KAB ?? 0);
    return {
      isKecamatan: noKec > 0,
      isKabkota: noKab > 0 && noKec <= 0,
    };
  }, [user?.S_NO_KAB, user?.S_NO_KEC]);

  const sessionKecamatanCode = useMemo(() => {
    return String(user?.S_NO_KEC ?? "").replace(/\D/g, "").replace(/^0+/, "");
  }, [user?.S_NO_KEC]);

  const isLocationProductSelected = Boolean(form.locationId && form.productId);
  const isNikEnabled = isLocationProductSelected;
  const isNikFilled = Boolean(form.nik.trim());
  const isDetailFieldsEnabled = isNikFilled;
  const isSaveEnabled = Boolean(
    form.locationId &&
    form.productId &&
    form.nik.trim() &&
    form.name.trim() &&
    form.noKec &&
    form.noKec !== "0" &&
    form.noKel &&
    form.noKel !== "0" &&
    form.alamat.trim() &&
    form.rw.trim() &&
    form.rt.trim() &&
    form.phone.trim() &&
    form.email.trim()
  );

  const filteredLocations = useMemo(() => {
    return locations.filter((item) => {
      const type = String(item.type || "").trim().toUpperCase();
      const itemCode = String(item.code || "").replace(/\D/g, "").replace(/^0+/, "");
      if (userLocationScope.isKecamatan) {
        if (type !== "KECAMATAN") return false;
        if (!sessionKecamatanCode) return true;
        return itemCode === sessionKecamatanCode;
      }
      if (userLocationScope.isKabkota) return type !== "KECAMATAN";
      return true;
    });
  }, [locations, userLocationScope, sessionKecamatanCode]);

  const productsByLocation = useMemo(() => {
    const locationId = Number(form.locationId || 0);
    if (!locationId) return [];
    const allowed = new Set(relations.filter((rel) => rel.locationId === locationId).map((rel) => rel.productId));
    return products.filter((product) => allowed.has(product.productId));
  }, [form.locationId, products, relations]);

  const filterProducts = useMemo(() => {
    const locationId = Number(filters.locationId || 0);
    if (!locationId) return products;
    const allowed = new Set(relations.filter((rel) => rel.locationId === locationId).map((rel) => rel.productId));
    return products.filter((product) => allowed.has(product.productId));
  }, [filters.locationId, products, relations]);

  const currentKelurahanOptions = useMemo(() => {
    return kelurahanCache[form.noKec] ?? [];
  }, [form.noKec, kelurahanCache]);

  const kecamatanSelectOptions = useMemo(
    () => mergeOptions(kecamatanOptions, true, "-- Pilih Kecamatan --"),
    [kecamatanOptions]
  );

  const kelurahanSelectOptions = useMemo(
    () => mergeOptions(currentKelurahanOptions, true, "-- Pilih Kelurahan --"),
    [currentKelurahanOptions]
  );

  const columns = useMemo(
    () => [
      { data: null, title: "No", render: (_: any, __: any, ___: any, meta: any) => meta.row + 1 },
      {
        data: null,
        title: "Aksi",
        orderable: false,
        width: "188px",
        className: "dt-actions",
        render: (_: any, __: any, row: TrackingRow) => {
          const canUpdate = nextStatuses(row.status).length > 0;
          return `
            <div class="grid min-w-[168px] grid-cols-4 gap-1">
              <button title="Cetak resi" aria-label="Cetak resi" class="btn-print-resi inline-flex h-8 w-8 items-center justify-center rounded-md border border-cyan-500/40 bg-cyan-500/15 text-cyan-50 transition hover:bg-cyan-500/25" data-id="${row.trackingId}">${actionIcons.print}</button>
              <button title="Edit pengajuan" aria-label="Edit pengajuan" class="btn-edit-tracking inline-flex h-8 w-8 items-center justify-center rounded-md border border-sky-500/40 bg-sky-500/15 text-sky-50 transition hover:bg-sky-500/25" data-id="${row.trackingId}">${actionIcons.edit}</button>
              <button title="Hapus pengajuan" aria-label="Hapus pengajuan" class="btn-delete-tracking inline-flex h-8 w-8 items-center justify-center rounded-md border border-rose-500/40 bg-rose-500/15 text-rose-50 transition hover:bg-rose-500/25" data-id="${row.trackingId}">${actionIcons.trash}</button>
              <button title="Perbarui status" aria-label="Perbarui status" class="btn-update-status inline-flex h-8 w-8 items-center justify-center rounded-md border border-emerald-500/40 bg-emerald-500/15 text-emerald-50 transition hover:bg-emerald-500/25 disabled:cursor-not-allowed disabled:opacity-40" data-id="${row.trackingId}" ${canUpdate ? "" : "disabled"}>${actionIcons.status}</button>
            </div>
          `;
        },
      },
      { data: "registrationNo", title: "No Registrasi" },
      { data: "nik", title: "NIK" },
      { data: "name", title: "Nama" },
      { data: "productName", title: "Jenis Pelayanan" },
      { data: "locationName", title: "Lokasi" },
      { data: "createdDate", title: "Tanggal" },
      { data: "createdTime", title: "Jam" },
      {
        data: "status",
        title: "Status",
        render: (data: string) => `<span class="inline-flex rounded-full border px-2.5 py-1 text-[11px] font-semibold ${statusClass(data)}">${statusLabel(data)}</span>`,
      },
      { data: "createdBy", title: "Petugas" },
    ],
    []
  );

  async function loadMaster() {
    const res = await fetch("/api/tracking-pengajuan/master", { cache: "no-store" });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json.success === false) throw new Error(json.message || "Gagal memuat master tracking");
    setLocations(json.data?.locations || []);
    setProducts(json.data?.products || []);
    setRelations(json.data?.relations || []);
  }

  async function loadWilayahMeta() {
    const res = await fetch("/api/check/ktpel/meta", { cache: "no-store", credentials: "include" });
    const payload = await res.json().catch(() => ({}));
    if (!res.ok || payload.success === false || !payload.data) throw new Error(payload.message || "Gagal memuat wilayah");

    const meta = payload.data as KtpelMeta;
    const defaultNoKec = convertWilayahCode(meta.defaults?.noKec);
    const defaultNoKel = convertWilayahCode(meta.defaults?.noKel);
    const kecamatan = Array.isArray(meta.wilayah?.kecamatan) ? meta.wilayah.kecamatan : [];
    const kelurahan = Array.isArray(meta.wilayah?.kelurahan) ? meta.wilayah.kelurahan : [];

    setKtpelMeta(meta);
    setKecamatanOptions(kecamatan);
    if (defaultNoKec !== "0" && kelurahan.length > 0) {
      setKelurahanCache((prev) => ({ ...prev, [defaultNoKec]: kelurahan }));
    }
    setForm((prev) => {
      const kecLabel = selectedWilayahLabel(kecamatan, defaultNoKec);
      const kelLabel = selectedWilayahLabel(kelurahan, defaultNoKel);
      return {
        ...prev,
        noKec: defaultNoKec,
        noKel: defaultNoKel,
        kecamatan: kecLabel,
        kelurahan: kelLabel,
      };
    });
  }

  async function fetchKelurahanOptions(value: string): Promise<WilayahOption[]> {
    if (!ktpelMeta || !value || value === "0") return [];
    if (kelurahanCache[value]) return kelurahanCache[value];

    setKelurahanLoadingKey(value);
    try {
      const params = new URLSearchParams({ no_kec: value });
      params.set("no_prop", ktpelMeta.defaults.noProp);
      params.set("no_kab", ktpelMeta.defaults.noKab);

      const res = await fetch(`/api/check/ktpel/kelurahan?${params.toString()}`, {
        cache: "no-store",
        credentials: "include",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json().catch(() => ({}));
      const list: WilayahOption[] = json?.data?.kelurahan ?? json?.kelurahan ?? [];
      setKelurahanCache((prev) => ({ ...prev, [value]: list }));
      return list;
    } finally {
      setKelurahanLoadingKey(null);
    }
  }

  async function handleKecamatanChange(value: string) {
    const kecamatan = selectedWilayahLabel(kecamatanOptions, value);
    setForm((prev) => ({
      ...prev,
      noKec: value,
      noKel: "0",
      kecamatan,
      kelurahan: "",
    }));
    if (value === "0" || kelurahanCache[value]) return;

    try {
      await fetchKelurahanOptions(value);
    } catch (e: any) {
      setNotice({ kind: "error", title: "Kelurahan Gagal Dimuat", message: e?.message || "Gagal memuat daftar kelurahan" });
    }
  }

  async function lookupNikByValue(nik: string) {
    if (nik.length !== 16) return;
    setNikLookupLoading(true);

    try {
      const res = await fetch("/api/tracking-pengajuan/lookup-nik", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        cache: "no-store",
        body: JSON.stringify({ nik }),
      });
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok || json.success === false) {
        if (json.message) {
          setNotice({ kind: "error", title: "Lookup NIK Gagal", message: json.message });
        }
        return;
      }

      const data = json.data;
      if (!data?.found) return;

      const noKec = convertWilayahCode(String(data.noKec ?? "0"));
      const noKel = convertWilayahCode(String(data.noKel ?? "0"));
      const kecLabel = selectedWilayahLabel(kecamatanOptions, noKec);

      let kelLabel = "";
      if (noKec !== "0") {
        const list = await fetchKelurahanOptions(noKec);
        kelLabel = selectedWilayahLabel(list, noKel);
      }

      setForm((prev) => ({
        ...prev,
        nik: normalizeDigits(String(data.nik ?? prev.nik)),
        name: String(data.name ?? "").toUpperCase(),
        noKec,
        kecamatan: kecLabel,
        noKel,
        kelurahan: kelLabel,
        alamat: String(data.alamat ?? prev.alamat),
        rw: String(data.rw ?? prev.rw),
        rt: String(data.rt ?? prev.rt),
      }));
    } catch (e: any) {
      setNotice({ kind: "error", title: "Lookup NIK Gagal", message: e?.message || "Gagal mencari data NIK" });
    } finally {
      setNikLookupLoading(false);
    }
  }

  useEffect(() => {
    const normalized = normalizeDigits(form.nik);
    if (normalized.length !== 16) {
      lastNikLookupRef.current = "";
      return;
    }
    if (lastNikLookupRef.current === normalized) return;
    lastNikLookupRef.current = normalized;
    void lookupNikByValue(normalized);
  }, [form.nik]);

  function handleKelurahanChange(value: string) {
    setForm((prev) => ({
      ...prev,
      noKel: value,
      kelurahan: selectedWilayahLabel(currentKelurahanOptions, value),
    }));
  }

  async function loadRows(nextFilters = filters) {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(nextFilters).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });
      const res = await fetch(`/api/tracking-pengajuan?${params.toString()}`, { cache: "no-store" });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal memuat tracking pengajuan");
      setRows(json.data?.rows || []);
      setSummary(json.data?.summary || {});
    } catch (e: any) {
      setNotice({ kind: "error", title: "Gagal Memuat", message: e?.message || "Gagal memuat tracking pengajuan" });
      setRows([]);
      setSummary({});
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void (async () => {
      try {
        await Promise.all([loadMaster(), loadWilayahMeta()]);
        await loadRows();
      } catch (e: any) {
        setNotice({ kind: "error", title: "Inisialisasi Gagal", message: e?.message || "Gagal memuat modul tracking" });
      }
    })();
  }, []);

  useEffect(() => {
    if (form.productId && !productsByLocation.some((item) => String(item.productId) === form.productId)) {
      setForm((prev) => ({ ...prev, productId: "" }));
    }
  }, [form.locationId, productsByLocation]);

  useEffect(() => {
    if (filters.productId && !filterProducts.some((item) => String(item.productId) === filters.productId)) {
      setFilters((prev) => ({ ...prev, productId: "" }));
    }
  }, [filters.locationId, filterProducts]);

  const detachTableClick = () => {
    if (tableHostRef.current) {
      tableHostRef.current.removeEventListener("click", onTableClick as any);
      tableHostRef.current = null;
    }
  };

  const handleApiReady = (api: any | null) => {
    if (!api) {
      detachTableClick();
      return;
    }
    const container = api.table().container() as HTMLElement;
    if (tableHostRef.current && tableHostRef.current !== container) {
      tableHostRef.current.removeEventListener("click", onTableClick as any);
    }
    tableHostRef.current = container;
    container.addEventListener("click", onTableClick as any);
  };

  const onTableClick = (e: MouseEvent) => {
    const target = e.target as HTMLElement;
    const printBtn = target.closest("[data-id].btn-print-resi") as HTMLElement | null;
    const editBtn = target.closest("[data-id].btn-edit-tracking") as HTMLElement | null;
    const deleteBtn = target.closest("[data-id].btn-delete-tracking") as HTMLElement | null;
    const statusBtn = target.closest("[data-id].btn-update-status") as HTMLButtonElement | null;
    if (printBtn) {
      const row = rows.find((item) => item.trackingId === Number(printBtn.dataset.id));
      if (row) printReceipt(row);
      return;
    }
    if (editBtn) {
      const row = rows.find((item) => item.trackingId === Number(editBtn.dataset.id));
      if (row) void startEditTracking(row.trackingId);
      return;
    }
    if (deleteBtn) {
      const row = rows.find((item) => item.trackingId === Number(deleteBtn.dataset.id));
      if (row) void deleteTracking(row);
      return;
    }
    if (statusBtn && !statusBtn.disabled) {
      const row = rows.find((item) => item.trackingId === Number(statusBtn.dataset.id));
      if (!row) return;
      const next = nextStatuses(row.status);
      setStatusModal({ row, next });
      setStatusValue(next[0] || "");
      setStatusDescription("");
    }
  };

  useEffect(() => () => detachTableClick(), []);

  function resetTrackingForm() {
    setEditingRowId(null);
    setForm(emptyForm);
    lastNikLookupRef.current = "";
  }

  async function startEditTracking(trackingId: number) {
    try {
      const res = await fetch(`/api/tracking-pengajuan/${trackingId}`, { cache: "no-store" });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal memuat detail pengajuan");

      const item = json.data?.item;
      if (!item) throw new Error("Data pengajuan tidak ditemukan");

      const noKec = convertWilayahCode(String(item.kecamatan ?? item.noKec ?? "0"));
      const noKel = convertWilayahCode(String(item.kelurahan ?? item.noKel ?? "0"));
      const kecamatan = selectedWilayahLabel(kecamatanOptions, noKec);
      let kelurahan = String(item.kelurahanLabel ?? "").trim();
      if (!kelurahan && noKec !== "0") {
        const options = await fetchKelurahanOptions(noKec);
        kelurahan = selectedWilayahLabel(options, noKel);
      }

      setEditingRowId(trackingId);
      setForm({
        locationId: String(item.locationId ?? ""),
        productId: String(item.productId ?? ""),
        nik: normalizeDigits(String(item.nik ?? "")),
        name: String(item.name ?? item.applicantName ?? "").toUpperCase(),
        noKec,
        noKel,
        kecamatan,
        kelurahan,
        alamat: String(item.alamat ?? ""),
        rw: String(item.noRw ?? item.rw ?? ""),
        rt: String(item.noRt ?? item.rt ?? ""),
        phone: String(item.phone ?? ""),
        email: String(item.email ?? ""),
        notes: String(item.notes ?? ""),
      });
    } catch (e: any) {
      setNotice({ kind: "error", title: "Edit Gagal", message: e?.message || "Gagal membuka data untuk diedit" });
    }
  }

  async function deleteTracking(row: TrackingRow) {
    const confirmed = window.confirm(`Hapus pengajuan ${row.registrationNo}? Data akan dinonaktifkan dari daftar.`);
    if (!confirmed) return;

    setSaving(true);
    try {
      const res = await fetch(`/api/tracking-pengajuan/${row.trackingId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal menghapus pengajuan");
      if (editingRowId === row.trackingId) resetTrackingForm();
      setNotice({ kind: "success", title: "Pengajuan Dihapus", message: json.message || "Data pengajuan berhasil dihapus" });
      await loadRows();
    } catch (e: any) {
      setNotice({ kind: "error", title: "Gagal Hapus", message: e?.message || "Gagal menghapus pengajuan" });
    } finally {
      setSaving(false);
    }
  }

  async function saveTracking() {
    setSaving(true);
    try {
      const payload = {
        locationId: form.locationId,
        productId: form.productId,
        nik: form.nik,
        applicantName: form.name,
        noKec: form.noKec,
        noKel: form.noKel,
        alamat: form.alamat,
        noRw: form.rw,
        noRt: form.rt,
        phone: form.phone,
        email: form.email,
        source: "MANUAL",
        notes: form.notes || "",
      };
      const endpoint = editingRowId ? `/api/tracking-pengajuan/${editingRowId}` : "/api/tracking-pengajuan";
      const res = await fetch(endpoint, {
        method: editingRowId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify(payload),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal menyimpan pengajuan");
      const item = json.data?.item as TrackingRow;
      resetTrackingForm();
      setNotice({
        kind: "success",
        title: editingRowId ? "Pengajuan Diperbarui" : "Pengajuan Disimpan",
        message: editingRowId
          ? `Nomor registrasi ${item.registrationNo} berhasil diperbarui.`
          : `Nomor registrasi ${item.registrationNo} berhasil dibuat. Silakan cetak resi dari tombol Resi di tabel.`,
      });
      await loadRows();
    } catch (e: any) {
      setNotice({ kind: "error", title: editingRowId ? "Gagal Update" : "Gagal Menyimpan", message: e?.message || "Gagal menyimpan pengajuan" });
    } finally {
      setSaving(false);
    }
  }

  async function updateStatus() {
    if (!statusModal || !statusValue) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/tracking-pengajuan/${statusModal.row.trackingId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ status: statusValue, description: statusDescription }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal memperbarui status");
      setStatusModal(null);
      setNotice({ kind: "success", title: "Status Diperbarui", message: json.message || "Status tracking berhasil diperbarui" });
      await loadRows();
    } catch (e: any) {
      setNotice({ kind: "error", title: "Gagal Update Status", message: e?.message || "Gagal memperbarui status" });
    } finally {
      setSaving(false);
    }
  }

  async function searchTracking() {
    setSearching(true);
    try {
      const params = new URLSearchParams({ q: searchTerm.trim() });
      const res = await fetch(`/api/tracking-pengajuan/search?${params.toString()}`, { cache: "no-store" });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === false) throw new Error(json.message || "Gagal mencari tracking");
      setSearchRows(json.data?.rows || []);
    } catch (e: any) {
      setNotice({ kind: "error", title: "Pencarian Gagal", message: e?.message || "Gagal mencari tracking" });
      setSearchRows([]);
    } finally {
      setSearching(false);
    }
  }

  function getLocationLabel(row: TrackingRow) {
    if (row.locationId >= 1 && row.locationId <= 30) {
      return `KECAMATAN ${row.locationName}`;
    }
    if (row.locationId >= 31 && row.locationId <= 36) {
      return `GEULIS ${row.locationName}`;
    }
    if (row.locationCode === "99" || row.locationName?.toUpperCase() === "DINAS") {
      return "DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL KOTA BANDUNG";
    }
    return row.locationName;
  }

  function formatProductHeading(productName: string) {
    const normalized = productName?.trim()?.toUpperCase() || "";
    if (normalized.includes("KARTU IDENTITAS ANAK")) {
      return "KARTU IDENTITAS ANAK (KIA)";
    }
    return productName;
  }

  function printReceipt(row: TrackingRow) {
    const win = window.open("", "_blank", "width=420,height=680");
    if (!win) return;
    const locationLabel = getLocationLabel(row);
    const productHeading = formatProductHeading(row.productName);
    const rt = String(row.rt ?? 0).padStart(3, "0");
    const rw = String(row.rw ?? 0).padStart(3, "0");
    const rtRw = `${rt}/${rw}`;
    const alamat = row.alamat || "-";
    const kelurahan = row.kelurahan || "-";
    const kecamatan = row.kecamatan || "-";
    const logoHeader = "/assets/plugins/images/Header Resi.svg";
    const logoWatermark = "/assets/plugins/images/wm.png";
    const icons = {
      user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>`,
      map: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s7-5.5 7-12a7 7 0 10-14 0c0 6.5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/></svg>`,
      clipboard: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="4" width="14" height="18" rx="2"/><path d="M9 4h6v3H9z"/></svg>`,
      shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l7 3v6c0 5-3 8-7 9-4-1-7-4-7-9V6z"/><path d="M9 12l2 2 4-4"/></svg>`,
      calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>`,
      clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/></svg>`,
      phone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 01-2.2 2A19.8 19.8 0 013 5.2 2 2 0 015 3h3a2 2 0 012 1.7l.4 2.6a2 2 0 01-.6 1.8l-1.6 1.6a16 16 0 007 7l1.6-1.6a2 2 0 011.8-.6l2.6.4A2 2 0 0122 16.9z"/></svg>`,
      mail: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>`,
      globe: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/></svg>`,
    } as const;

    const receiptSection = (copyLabel: string) => `
      <div class="receipt">
        <div class="watermark"><img src="${logoWatermark}" alt="Watermark" /></div>
        <div class="copy-tag">${copyLabel}</div>
        <div class="wrap">
          <div class="head">
            <img class="header-logo" src="${logoHeader}" onerror="this.onerror=null;this.src='/assets/plugins/images/Header Resi.png';" alt="Header Resi" />
            <div class="header-text">
              <div class="small">PEMERINTAH KOTA BANDUNG</div>
              <div class="big">DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL KOTA BANDUNG</div>
              <div class="meta">Jl. Ambon No.1B, Kota Bandung, Jawa Barat 40115 | Telp. (022) 4209891</div>
              <div class="meta-icons">
                <span class="meta-item">${icons.phone}<span>(022) 4209891</span></span>
                <span class="meta-item">${icons.globe}<span>disdukcapil.bandung.go.id</span></span>
                <span class="meta-item">${icons.mail}<span>disdukcapilkotabdg@gmail.com</span></span>
              </div>
            </div>
            <div class="head-spacer" aria-hidden="true"></div>
          </div>
          <div class="rule"></div>
          <div class="title-block">
            <div class="main">BUKTI REGISTRASI PENGAJUAN</div>
            <div class="sub">LAYANAN ADMINISTRASI KEPENDUDUKAN</div>
          </div>
          <div class="register-focus">
            <div class="register-focus-label">NOMOR REGISTRASI</div>
            <div class="register-focus-value">${row.registrationNo}</div>
          </div>
          <div class="rule"></div>
          <div class="content-grid">
            <div class="left-col">
              <div class="section">
                <div class="section-title">${icons.user}<span>1. IDENTITAS PEMOHON</span></div>
                <table class="info-table">
                  <tbody>
                    <tr><td class="label">NIK</td><td class="value">: ${row.nik}</td></tr>
                    <tr><td class="label">Nama</td><td class="value">: ${row.name}</td></tr>
                    <tr><td class="label icon-label">${icons.phone}<span>Nomor HP</span></td><td class="value">: ${row.phone || "-"}</td></tr>
                    <tr><td class="label icon-label">${icons.mail}<span>Email</span></td><td class="value">: ${row.email || "-"}</td></tr>
                  </tbody>
                </table>
              </div>
              <div class="section">
                <div class="section-title">${icons.map}<span>2. ALAMAT</span></div>
                <table class="info-table">
                  <tbody>
                    <tr><td class="label">Alamat</td><td class="value">: ${alamat}</td></tr>
                    <tr><td class="label">RT / RW</td><td class="value">: ${rtRw}</td></tr>
                    <tr><td class="label">Kelurahan</td><td class="value">: ${kelurahan}</td></tr>
                    <tr><td class="label">Kecamatan</td><td class="value">: ${kecamatan}</td></tr>
                  </tbody>
                </table>
              </div>
              <div class="section">
                <div class="section-title">${icons.clipboard}<span>3. DETAIL PENGAJUAN</span></div>
                <table class="info-table">
                  <tbody>
                    <tr><td class="label">Jenis Layanan</td><td class="value">: ${productHeading}</td></tr>
                    <tr><td class="label">Lokasi Layanan</td><td class="value">: ${locationLabel}</td></tr>
                    <tr><td class="label icon-label">${icons.calendar}<span>Tanggal</span></td><td class="value">: ${row.createdDate}</td></tr>
                    <tr><td class="label icon-label">${icons.clock}<span>Jam</span></td><td class="value">: ${row.createdTime} WIB</td></tr>
                    <tr><td class="label">Status</td><td class="value"><span class="status">${row.statusLabel || statusLabel(row.status)}</span></td></tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="right-col">
              <div class="qr-box">
                <div class="qr-title">${icons.shield}<span>4. VERIFIKASI</span></div>
                <img src="${qrUrl(row.registrationNo)}" alt="QR Code" />
                <div class="qr-note">Gunakan QR Code atau Nomor Registrasi untuk memantau status pengajuan.</div>
              </div>
              <div class="doc-meta">
                <table class="meta-table">
                  <tbody>
                    <tr><td class="meta-label">Dokumen</td><td class="meta-value">: Bukti Registrasi</td></tr>
                    <tr><td class="meta-label">No.</td><td class="meta-value">: ${row.registrationNo}</td></tr>
                    <tr><td class="meta-label">Tanggal Cetak</td><td class="meta-value">: ${row.createdDate} ${row.createdTime} WIB</td></tr>
                    <tr><td class="meta-label">Versi</td><td class="meta-value">: 1.0</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="rule"></div>
          <div class="footer">
            <span class="footer-shield">${icons.shield}</span>
            <span>Dokumen ini diterbitkan melalui Sistem MONALISA sebagai bukti registrasi pengajuan layanan administrasi kependudukan.</span>
            <span>Pindai Kode QR Verifikasi atau gunakan Nomor Registrasi untuk memantau perkembangan status pengajuan.</span>
          </div>
        </div>
      </div>
    `;
    const html = `<!doctype html>
      <html>
      <head>
        <title>Bukti Registrasi Pengajuan ${row.registrationNo}</title>
        <style>
          *{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}
          body{font-family:Arial,sans-serif;margin:0;padding:0;background:#fff;color:#111}
          @page{size:A4 portrait;margin:5mm}
          .sheet{width:200mm;height:287mm;display:grid;grid-template-rows:141mm 1mm 141mm}
          .receipt{height:141mm;padding:4mm 4.5mm;page-break-inside:avoid;overflow:hidden;position:relative}
          .cut-line{border-top:1px dashed #777;margin:0}
          .watermark{position:absolute;inset:0;display:grid;place-items:center;pointer-events:none;user-select:none}
          .watermark img{width:690px;height:690px;object-fit:contain;opacity:.12;filter:grayscale(1) contrast(1.05)}
          .copy-tag{position:absolute;top:4mm;right:4.5mm;background:#000;color:#fff;padding:1px 8px;font-size:8.6px;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
          .wrap{width:100%;margin:0 auto;display:grid;gap:4px;position:relative;z-index:1}
          .rule{height:1px;background:#000}
          .head{display:grid;grid-template-columns:58px 1fr 58px;gap:6px;align-items:center}
          .header-logo{width:58px;height:38px;object-fit:contain}
          .header-text{display:flex;flex-direction:column;gap:1px;align-items:center;text-align:center}
          .header-text .small{font-size:8.6px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
          .header-text .big{font-size:12px;font-weight:900;text-transform:uppercase;line-height:1.05;text-align:center}
          .header-text .meta{font-size:8px;font-weight:600;color:#444;line-height:1.15;text-align:center}
          .meta-icons{display:flex;gap:8px;align-items:center;justify-content:center;flex-wrap:wrap}
          .meta-item{display:inline-flex;align-items:center;gap:3px;font-size:7.2px;color:#333;font-weight:600}
          .meta-item svg{width:10px;height:10px;flex:none}
          .head-spacer{width:58px;height:38px}
          .title-block{display:grid;gap:2px;text-align:center;margin-top:2px}
          .title-block .main{font-size:14px;font-weight:900;text-transform:uppercase;letter-spacing:.03em}
          .title-block .sub{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.02em}
          .register-focus{border-top:1px solid #000;border-bottom:1px solid #000;padding:2px 6px;text-align:center}
          .register-focus-label{font-size:8.6px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
          .register-focus-value{font-size:13px;font-weight:900;letter-spacing:.01em;line-height:1.1;margin-top:1px;word-break:break-word}
          .content-grid{display:grid;grid-template-columns:68% 32%;gap:8px;align-items:start}
          .left-col{display:grid;gap:3px}
          .section{display:grid;gap:2px}
          .section-title{display:flex;align-items:center;gap:5px;font-size:9.8px;font-weight:900;text-transform:uppercase;letter-spacing:.03em;border-bottom:1px solid #000;padding-bottom:1px}
          .section-title svg{width:12px;height:12px;flex:none}
          .info-table{width:100%;border-collapse:collapse;table-layout:fixed}
          .info-table td{padding:.5px 0;font-size:9.3px;vertical-align:top;line-height:1.15}
          .info-table .label{width:96px;font-weight:700;white-space:nowrap;padding-right:6px}
          .info-table .label.icon-label{display:flex;align-items:center;gap:3px}
          .info-table .label.icon-label svg{width:9px;height:9px;flex:none}
          .info-table .value{font-weight:600;word-break:break-word}
          .right-col{display:grid;gap:4px}
          .qr-box{border:1px solid #000;padding:4px;display:grid;justify-items:center;gap:3px}
          .qr-box .qr-title{display:flex;align-items:center;gap:4px;font-size:8.8px;font-weight:800;letter-spacing:.04em;text-transform:uppercase}
          .qr-box .qr-title svg{width:10px;height:10px;flex:none}
          .qr-box img{width:112px;height:112px;display:block}
          .qr-note{font-size:8.2px;line-height:1.15;text-align:center;font-weight:600;color:#333}
          .doc-meta{border:1px dashed #8a8a8a;padding:4px}
          .meta-table{width:100%;border-collapse:collapse;table-layout:fixed}
          .meta-table td{font-size:8.6px;line-height:1.15;vertical-align:top;padding:.5px 0}
          .meta-label{width:72px;font-weight:700;white-space:nowrap}
          .meta-value{font-weight:600;word-break:break-word}
          .status{display:inline-block;padding:1px 6px;border:1px solid #000;font-weight:900;text-transform:uppercase;font-size:8.6px;letter-spacing:.02em}
          .footer{font-size:8.5px;line-height:1.2;color:#333;text-align:center;display:grid;gap:1px;justify-items:center;padding-top:1px}
          .footer-shield svg{width:12px;height:12px}
          .footer strong{font-weight:800}
          @media print{
            body{margin:0}
            .noprint{display:none}
            .sheet{width:200mm;height:287mm}
          }
        </style>
      </head>
      <body>
        <div class="sheet">
          ${receiptSection("UNTUK MASYARAKAT")}
          <div class="cut-line"></div>
          ${receiptSection("UNTUK PETUGAS")}
        </div>
        <script>
          window.onload = function() {
            const images = Array.from(document.querySelectorAll('img.header-logo'));
            if (!images.length || images.every((img) => img.complete)) {
              setTimeout(() => window.print(), 250);
              return;
            }
            let resolved = 0;
            const done = function() {
              resolved += 1;
              if (resolved >= images.length) {
                setTimeout(() => window.print(), 250);
              }
            };
            images.forEach((img) => {
              if (img.complete) {
                done();
                return;
              }
              img.addEventListener('load', done, { once: true });
              img.addEventListener('error', done, { once: true });
            });
          }
        </script>
      </body>
      </html>`;
    win.document.open();
    win.document.write(html);
    win.document.close();
  }

  return (
    <div className="relative mt-16 space-y-8 px-4 pb-10 pt-6 text-gray-100 sm:px-6 md:px-8 md:pt-8">
      <SettingPageHeader
        lead="Pelayanan"
        title="Tracking Pengajuan"
        description="Registrasi manual, monitoring status, pencarian pengajuan, dan cetak resi pelayanan Disdukcapil."
        badges={<span className="rounded-full border border-cyan-400/50 bg-cyan-500/15 px-3 py-1 text-xs font-semibold text-cyan-100">Manual Tracking</span>}
      />

      <section className="grid grid-cols-1 gap-6">
        <div className="rounded-3xl border border-cyan-900/50 bg-[#05070d]/80 p-5 shadow-[0_0_34px_#00ffff22]">
          <div className="mb-4 flex items-center gap-2 text-cyan-100">
            <FilePlus2 className="h-5 w-5 text-cyan-300" />
            <h2 className="text-sm font-semibold">{editingRowId ? "Edit Pengajuan" : "Input Pengajuan"}</h2>
          </div>
          {editingRowId ? (
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-2xl border border-sky-500/30 bg-sky-500/10 px-3 py-2 text-xs text-sky-50">
              <span>Sedang mengedit pengajuan</span>
              <span className="font-semibold">#{editingRowId}</span>
              <button onClick={resetTrackingForm} className="ml-auto inline-flex items-center gap-1 rounded-lg border border-sky-400/40 bg-sky-500/15 px-2.5 py-1 font-semibold hover:bg-sky-500/25">
                <X className="h-3.5 w-3.5" />
                Batal Edit
              </button>
            </div>
          ) : null}
          <div className="grid gap-3">
            <select value={form.locationId} onChange={(e) => setForm({ ...form, locationId: e.target.value })} className="rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50 outline-none">
              <option value="">Pilih Lokasi Layanan</option>
              {filteredLocations.map((item) => <option key={item.locationId} value={item.locationId}>{item.code} - {item.name}</option>)}
            </select>
            <select value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className="rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50 outline-none">
              <option value="">Pilih Jenis Pelayanan</option>
              {productsByLocation.map((item) => <option key={item.productId} value={item.productId}>{item.code} - {item.name}</option>)}
            </select>
            <input
              value={form.nik}
              onChange={(e) => setForm({ ...form, nik: normalizeDigits(e.target.value) })}
              placeholder="NIK Pemohon"
              disabled={!isNikEnabled}
              className={`rounded-xl border px-3 py-2 text-sm outline-none ${isNikEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
            />
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value.toUpperCase() })}
              placeholder="Nama Pemohon"
              disabled={!isDetailFieldsEnabled}
              className={`rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
            />
            <div className="grid gap-3 sm:grid-cols-2">
              <SelectDark
                value={form.noKec}
                onChange={(e) => void handleKecamatanChange(e.target.value)}
                disabled={!isDetailFieldsEnabled}
                className="rounded-xl"
              >
                {kecamatanSelectOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </SelectDark>
              <SelectDark
                value={form.noKel}
                onChange={(e) => handleKelurahanChange(e.target.value)}
                disabled={!isDetailFieldsEnabled || form.noKec === "0" || kelurahanLoadingKey === form.noKec}
                className="rounded-xl"
              >
                {kelurahanSelectOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {kelurahanLoadingKey === form.noKec && opt.value === "0" ? "Memuat kelurahan..." : opt.label}
                  </option>
                ))}
              </SelectDark>
            </div>
            <textarea
              value={form.alamat}
              onChange={(e) => setForm({ ...form, alamat: e.target.value })}
              placeholder="Alamat"
              disabled={!isDetailFieldsEnabled}
              rows={2}
              className={`min-h-[64px] rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
            />
            <div className="grid gap-3 sm:grid-cols-2">
              <input
                value={form.rw}
                onChange={(e) => setForm({ ...form, rw: e.target.value.replace(/[^\d]/g, "").slice(0, 3) })}
                placeholder="No RW"
                disabled={!isDetailFieldsEnabled}
                className={`rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
              />
              <input
                value={form.rt}
                onChange={(e) => setForm({ ...form, rt: e.target.value.replace(/[^\d]/g, "").slice(0, 3) })}
                placeholder="No RT"
                disabled={!isDetailFieldsEnabled}
                className={`rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/[^\d+]/g, "").slice(0, 20) })}
                placeholder="No HP"
                disabled={!isDetailFieldsEnabled}
                className={`rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
              />
              <input
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="Email"
                disabled={!isDetailFieldsEnabled}
                className={`rounded-xl border px-3 py-2 text-sm outline-none ${isDetailFieldsEnabled ? "border-cyan-800/60 bg-[#0f172a] text-cyan-50" : "border-slate-700 bg-slate-900 text-slate-400"}`}
              />
            </div>
            <button
              onClick={() => void saveTracking()}
              disabled={!isSaveEnabled || saving}
              className={`mt-1 inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold text-black shadow-lg ${isSaveEnabled ? "bg-gradient-to-r from-cyan-400 to-blue-500 hover:opacity-95" : "bg-slate-700 text-slate-300 cursor-not-allowed"}`}
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
              {editingRowId ? "Simpan Perubahan" : "Simpan"}
            </button>
          </div>
        </div>

        <div className="space-y-5">
          <div className="grid gap-3 md:grid-cols-4">
            {STATUSES.map((status) => (
              <div key={status} className={`rounded-2xl border p-4 ${statusClass(status)}`}>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] opacity-75">{statusLabel(status)}</p>
                <p className="mt-2 text-3xl font-bold">{summary[status] || 0}</p>
              </div>
            ))}
          </div>

          <div className="rounded-3xl border border-cyan-900/50 bg-[#05070d]/80 p-5 shadow-[0_0_34px_#00ffff22]">
            <div className="flex flex-wrap items-center gap-3">
              <DateRangePopup start={filters.start} end={filters.end} onChange={(start, end) => setFilters({ ...filters, start, end })} months={2} minWidth={660} className="min-w-0" />
              <select value={filters.locationId} onChange={(e) => setFilters({ ...filters, locationId: e.target.value })} className="min-w-0 w-full sm:w-auto rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50">
                <option value="">Semua Lokasi</option>
                {filteredLocations.map((item) => <option key={item.locationId} value={item.locationId}>{item.code} - {item.name}</option>)}
              </select>
              <select value={filters.productId} onChange={(e) => setFilters({ ...filters, productId: e.target.value })} className="min-w-0 w-full sm:w-auto rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50">
                <option value="">Semua Pelayanan</option>
                {filterProducts.map((item) => <option key={item.productId} value={item.productId}>{item.name}</option>)}
              </select>
              <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })} className="min-w-0 w-full sm:w-auto rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50">
                <option value="">Semua Status</option>
                {STATUSES.map((status) => <option key={status} value={status}>{statusLabel(status)}</option>)}
              </select>
              <input value={filters.petugas} onChange={(e) => setFilters({ ...filters, petugas: e.target.value })} placeholder="Petugas" className="min-w-0 w-full sm:w-32 rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50" />
              <input value={filters.nik} onChange={(e) => setFilters({ ...filters, nik: normalizeDigits(e.target.value) })} placeholder="NIK" className="min-w-0 w-full sm:w-40 rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50" />
              <input value={filters.registrationNo} onChange={(e) => setFilters({ ...filters, registrationNo: e.target.value.toUpperCase() })} placeholder="Nomor Registrasi" className="min-w-0 w-full sm:w-56 rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50" />
              <button onClick={() => void loadRows()} disabled={loading} className="min-w-0 w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500/20 px-4 py-2 text-sm font-semibold text-cyan-50 hover:bg-cyan-500/30">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                Filter
              </button>
              <button onClick={() => void loadRows()} disabled={loading} className="min-w-0 w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-cyan-800/60 bg-white/5 px-3 py-2 text-sm text-cyan-100">
                <RefreshCcw className="h-4 w-4" />
                Reload
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-cyan-900/50 bg-[#05070d]/80 p-5 shadow-[0_0_34px_#00ffff22]">
        <div className="mb-4 flex items-center gap-2 text-cyan-100">
          <Clock3 className="h-5 w-5 text-cyan-300" />
          <h2 className="text-sm font-semibold">Monitoring Pengajuan</h2>
        </div>
        {loading ? (
          <div className="py-8 text-center text-cyan-100/70"><Loader2 className="mx-auto h-5 w-5 animate-spin" /><p className="mt-2 text-xs">Memuat data...</p></div>
        ) : (
          <JQDataTable data={rows as any[]} columns={columns} pageLength={25} tableClassName="dt-cyberpunk tracking-table" minWidth={0} onApiReady={handleApiReady} />
        )}
      </section>

      <section className="rounded-3xl border border-cyan-900/50 bg-[#05070d]/80 p-5 shadow-[0_0_34px_#00ffff22]">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-cyan-100">
            <ShieldCheck className="h-5 w-5 text-cyan-300" />
            <h2 className="text-sm font-semibold">Tracking</h2>
          </div>
          <div className="ml-auto flex flex-1 flex-wrap justify-end gap-2">
            <input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && searchTracking()} placeholder="Nomor Registrasi atau NIK" className="min-w-0 w-full max-w-[420px] rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50" />
            <button onClick={() => void searchTracking()} disabled={searching} className="min-w-0 w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500/20 px-4 py-2 text-sm font-semibold text-cyan-50 hover:bg-cyan-500/30">
              {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              Cari
            </button>
          </div>
        </div>
        {searchRows.length ? (
          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {searchRows.map((item) => (
              <div key={item.trackingId} className="rounded-2xl border border-cyan-900/50 bg-[#0f172a]/80 p-4 text-sm text-cyan-50">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{item.registrationNo}</p>
                    <p className="text-xs text-cyan-100/60">{item.date}</p>
                  </div>
                  <span className={`rounded-full border px-2 py-1 text-[11px] font-semibold ${statusClass(item.status)}`}>{item.statusLabel || statusLabel(item.status)}</span>
                </div>
                <div className="mt-3 space-y-1 text-xs text-cyan-100/75">
                  <p>{item.name} - {item.nik}</p>
                  <p>{item.productName}</p>
                  <p>{item.locationName}</p>
                </div>
              </div>
            ))}
          </div>
        ) : null}
      </section>

      {statusModal ? (
        <div className="fixed inset-0 z-[12000] flex items-center justify-center bg-black/70 px-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-cyan-500/30 bg-[#0b0f1c] p-5 shadow-[0_16px_40px_rgba(0,0,0,.55)]">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="mt-1 h-5 w-5 text-emerald-300" />
              <div className="min-w-0 flex-1">
                <h3 className="text-sm font-semibold text-cyan-50">Update Status</h3>
                <p className="mt-1 break-words text-xs text-cyan-100/65">{statusModal.row.registrationNo} - {statusModal.row.name}</p>
              </div>
              <button onClick={() => setStatusModal(null)} className="rounded-lg border border-cyan-800/50 p-2 text-cyan-100 hover:bg-white/10"><X className="h-4 w-4" /></button>
            </div>
            <div className="mt-4 grid gap-3">
              <select value={statusValue} onChange={(e) => setStatusValue(e.target.value as TrackingStatus)} className="rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50">
                {statusModal.next.map((status) => <option key={status} value={status}>{statusLabel(status)}</option>)}
              </select>
              <textarea value={statusDescription} onChange={(e) => setStatusDescription(e.target.value)} rows={3} placeholder="Keterangan perubahan status" className="resize-none rounded-xl border border-cyan-800/60 bg-[#0f172a] px-3 py-2 text-sm text-cyan-50 outline-none" />
              <button onClick={() => void updateStatus()} disabled={saving} className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500/20 px-4 py-2 text-sm font-semibold text-emerald-50 hover:bg-emerald-500/30">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                Simpan Status
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <NeonModal open={!!notice} kind={notice?.kind || "info"} title={notice?.title} message={notice?.message} onClose={() => setNotice(null)} />
    </div>
  );
}
